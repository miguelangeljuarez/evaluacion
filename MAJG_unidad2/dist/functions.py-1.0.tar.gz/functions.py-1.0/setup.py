from setuptools import setup
setup(
    name='functions.py',
    version='1.0',
    description='Calculate different functions',
    author='Miguel Angel Juarez Guerrero',
    author_email='miguel.juarez9723@gmail.com',
    url='trello.com/pa',
    py_modules=['functions'],
    )
